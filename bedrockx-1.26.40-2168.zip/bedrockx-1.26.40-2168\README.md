# BedrockX protocol update — Bedrock 1.26.40 / protocol 2168

This archive is a source-only snapshot of a BedrockX-derived protocol layer
prepared for review and upstream development. It is not a complete game client
release.

## Included

- `server/core/protocol/` — client, NetherNet transport, serializers, packet
  helpers, and protocol datatypes.
- `server/core/ext/protocol.json` — runtime protocol schema consumed by the
  serializer transform.
- `server/core/ext/data.json` — protocol/version metadata (`1.26.40`, network
  protocol `2168`).
- `server/core/protocol/index.d.ts` — updated public version declaration.

Native RakNet binaries, authentication data, account files, logs, generated
output, and installer files are intentionally excluded.

## 1.26.40 / 2168 compatibility work

- `resource_packs_info` uses an unsigned VarInt texture-pack count.
- `resource_pack_client_response` uses the current status and status-id fields.
- `start_game` uses current gamerule widths, education-offer and broadcast-mode
  VarInts, and the current field order.
- `creative_content` and network item stacks use the current extra-data layout.
- `set_entity_data` consumes the repeated metadata format byte.
- `level_chunk` and `subchunk` consume current counts, optional sections,
  cache/blob fields, and per-entry presence markers.
- `voxel_shapes` uses the current single `VoxelCells` record.
- `player_list` handles per-entry actions and the current embedded skin fields.
- `player_auth_input` follows the 2168 optional-section and input-flag order.
- Crafting data is consumed as a bounded opaque payload when no recipe consumer
  is present, preserving alignment for later packets.

## Suggested upstream pull request scope

Port the schema changes into BedrockX's versioned protocol definition and add
serializer round-trip tests for empty and populated arrays, optional sections,
metadata entries, and packet-144 input ordering. Keep application-specific
Realm, UI, command, and identity behavior outside the protocol change.

## Validation

The source was validated with focused packet, player-list, skin, movement, and
subchunk tests, TypeScript checking, and JavaScript syntax checks in the host
project. Install the target project's normal development dependencies before
running its own test suite.
